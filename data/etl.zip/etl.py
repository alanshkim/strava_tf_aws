import os
import json
import configparser
import boto3
import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

s3 = boto3.client('s3')

def extract_data_from_s3(bucket_name, object_keys):

    data_dict = {}

    for key in object_keys:
        try:
            response = s3.get_object(Bucket=bucket_name, Key=key)
            content = response['Body'].read().decode('utf-8')  # Decode the byte content
            json_data = json.loads(content)
            data_dict[key] = json_data  # Store the content by object key
        except Exception as e:
            print(f"Error fetching {key}: {e}")
            data_dict[key] = None  # Handle the error accordingly

    return data_dict


def convert_stats(stats):

    def seconds_to_hms(seconds):
        return str(datetime.timedelta(seconds=seconds))
    
    for key in stats.keys():

        if "distance" in stats[key]:         
            stats[key]["distance"] = round(stats[key]["distance"] / 1609.34, 2)  # Meters to miles
        if "moving_time" in stats[key]:
            stats[key]["moving_time"] = seconds_to_hms(stats[key]["moving_time"])  # Seconds to hh:mm:ss
        if "elapsed_time" in stats[key]:
            stats[key]["elapsed_time"] = seconds_to_hms(stats[key]["elapsed_time"])  # Seconds to hh:mm:ss
        if "elevation_gain" in stats[key]:
            stats[key]["elevation_gain"] = round(stats[key]["elevation_gain"] * 3.28084, 1)  # Meters to feet

    stats = json.dumps(stats)

    return stats

def convert_activities(activities):
    
    def seconds_to_minutes(seconds):
        return round(seconds / 60, 2)

    def mps_to_mph(mps):
        return round(mps * 2.23694, 1)

    # Filter out activities that are Weight Training.
    run_activities = [activity for activity in activities if activity.get('type') != 'WeightTraining']

    for activity in run_activities:
        activity['distance'] = round(activity['distance'] / 1609.34, 2)
        activity['total_elevation_gain'] = round(activity['total_elevation_gain'] * 3.28084, 1)
        activity['moving_time'] = seconds_to_minutes(activity['moving_time'])
        activity['elapsed_time'] = seconds_to_minutes(activity['elapsed_time'])
        activity['average_speed'] = mps_to_mph(activity['average_speed'])
        activity['max_speed'] = mps_to_mph(activity['max_speed'])
        # Garmin metrics. Some activities were recorded without it.
        if 'average_cadence' in activity:
            activity['steps_per_minute'] = round(activity['average_cadence'] * 2, 0)
        if 'elev_high' in activity:
            activity['elev_high'] = round(activity['elev_high'] * 3.28084, 1)
        if 'elev_low' in activity:    
            activity['elev_low'] = round(activity['elev_low'] * 3.28084, 1)

    run_activities = json.dumps(run_activities)

    return run_activities

def load_data_to_s3(s3, bucket_name, object_key, data):

    processed_key = f"processed/{object_key}"
    
    s3.put_object(
        Bucket=bucket_name,
        Key=processed_key,
        Body=data,
        ContentType='application/json'
    )
    
def lambda_handler(event, handler):
    
    config = configparser.ConfigParser()
    config.read(os.path.expanduser('~/etc/strava/config.conf'))

    BUCKET_NAME = os.environ['BUCKET_NAME']
    OBJECT_KEYS = os.environ['OBJECT_KEYS'].split(', ') # Keys stored as a list.

    processed_dict = {} 

    print("Starting data extraction from s3")
    s3_data = extract_data_from_s3(BUCKET_NAME, OBJECT_KEYS)
    print("Data extraction successful")

    STATS = s3_data['stats.json']
    ACTIVITIES = s3_data['activities.json']

    stats = convert_stats(STATS)
    processed_dict['stats.json'] = stats
    activities = convert_activities(ACTIVITIES)
    processed_dict['activities.json'] = activities
    print("Data transformation successful")

    print("Loading processed data to s3...")
    for key, data in processed_dict.items():
        load_data_to_s3(BUCKET_NAME, key, data)

    return {
        'statusCode': 200,
        'body': 'ETL successful'
    }
