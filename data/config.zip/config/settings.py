S3_BUCKET_NAME = "strava-run-bucket"
GLUE_JOB_NAME = "pyspark_glue_job"
GLUE_JOB_FILE = "activites.json"